package com.serenegiant.usb_libuvccamera;

public interface IButtonCallback {
    void onButton(int button, int state);
}
